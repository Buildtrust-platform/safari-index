/**
 * Local test runner for Decision Orchestrator
 * Invokes handler directly without HTTP/Lambda runtime
 *
 * Usage: npx ts-node src/test-local.ts
 *
 * Note: Requires DynamoDB Local or mocked AWS credentials
 */
export {};
//# sourceMappingURL=test-local.d.ts.map