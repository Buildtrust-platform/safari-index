"use strict";
/**
 * Safari Index Decision Orchestrator Types
 * Aligned with: 12_ai_prompts.md Standard Input Envelope
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map