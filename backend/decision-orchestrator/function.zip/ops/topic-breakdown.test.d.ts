/**
 * Topic Breakdown Aggregation Tests
 *
 * Tests the pure aggregation function without DynamoDB dependencies.
 * Run with: npx ts-node src/ops/topic-breakdown.test.ts
 */
export {};
//# sourceMappingURL=topic-breakdown.test.d.ts.map